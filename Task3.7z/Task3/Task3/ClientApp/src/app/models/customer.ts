export class Customer {
  Name: string;
  StartDate: Date;
  EndDate: Date;
}
