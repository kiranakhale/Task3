﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace Task3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TrainingController : ControllerBase
    {
        private static List<Customer> Customers = new List<Customer>();
        [HttpPost("[action]")]
        public IActionResult create(Customer customer)
        {
            if (customer == null)
                return BadRequest();
            string difference = string.Empty;
            Customers.Add(customer);
            difference = "Data submitted successfully. Date difference is " + Math.Round ((customer.EndDate - customer.StartDate).TotalDays);
            return Ok(difference);
        }

        public class Customer
        {
            public string Name { get; set; }
            public DateTime StartDate { get; set; }
            public DateTime EndDate { get; set; }
        }
    }
}