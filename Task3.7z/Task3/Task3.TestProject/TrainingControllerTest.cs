using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Net;
using Task3.Controllers;

namespace Task3.TestProject
{ 
    // Didnt mock this as i didnt implement DI in it hence directly called Controller
    [TestClass]
    public class TrainingControllerTest
    {
        private readonly TrainingController _trainingController;
        public TrainingControllerTest()
        {
            _trainingController = new TrainingController();
        }
        [TestMethod]
        public void CreateReturnSuccess()
        {
            //Arrange
            var startDate = DateTime.Now;
            var endDate = DateTime.Now.AddDays(1);
            //Act
            var response = _trainingController.create(new TrainingController.Customer() { EndDate = endDate  ,Name = "test", StartDate= startDate });
            var okResult = response as OkObjectResult;
            //Verify
            Assert.IsNotNull(okResult);
            Assert.AreEqual((int)HttpStatusCode.OK, okResult.StatusCode);
            Assert.AreEqual("Data submitted successfully. Date difference is "+ Math.Round((endDate  - startDate ).TotalDays), okResult.Value);

        }
        [TestMethod]
        public void CreateReturnBadRequest()
        {
            //Act
            var response = _trainingController.create(null);
            var badResult = response as BadRequestResult;
            //Verify
            Assert.IsNotNull(badResult);
            Assert.AreEqual((int)HttpStatusCode.BadRequest, badResult.StatusCode);
        }
    }
}
